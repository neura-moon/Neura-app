
import Head from 'next/head'
import Chatbot from '../components/Chatbot'
import Avatar from '../components/Avatar'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-100 flex flex-col items-center justify-center">
      <Head>
        <title>NEURA is Live</title>
      </Head>
      <Avatar />
      <Chatbot />
    </div>
  )
}
