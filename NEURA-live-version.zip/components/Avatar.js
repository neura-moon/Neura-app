
export default function Avatar() {
  return (
    <div className="mb-4">
      <img src="/avatar.png" alt="Avatar" className="w-24 h-24 rounded-full shadow-lg" />
    </div>
  );
}
