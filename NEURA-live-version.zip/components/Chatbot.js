
export default function Chatbot() {
  return (
    <div className="bg-white p-4 rounded shadow w-full max-w-md">
      <h2 className="text-xl font-bold mb-2">Talk to NEURA</h2>
      <input
        type="text"
        className="w-full p-2 border border-gray-300 rounded"
        placeholder="Type your message..."
      />
    </div>
  );
}
